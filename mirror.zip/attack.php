﻿<?php
include('header.php');
$site_hal = site_hal;
if (isset($_GET['zone'])) {
    $noS = $_GET['zone'];
}
else
    $noS = 1;

$offset = ($noS - 1) * $site_hal;
?>


		<br>					  
<div class="container">

<ul class="breadcrumb">
	<li>
		<i class="icon-home"></i>
		<a>Home</a> 
		<i class="icon-angle-right"></i>
	</li>
	<li><a href="/archive/1"><i class="fa fa-archive"></i> Archive</a></li>
</ul>
<?php
            
            

                $db->go("SELECT * FROM notify");
                $hit1 = $db->numRows();

			?>
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default" id="tables">
                    <div class="panel-heading"><i class="icon-globe"></i> Web Archive (Total Results : <?php echo $hit1; ?>)<b></b>
                    </div>
					<div class="panel-body">
						<table class="table table-hover">
							<thead>
							<tr>
									  <th style="width:15%;">Attacker</th>
									  <th style="width:6%;">Country</th>
									  <th style="width:6%;">Scheme</th>
									  <th style="width:20%;">Host</th>
									  <th style="width:20%;">Path</th>
									  <th style="width:20%;">Server İP</th>
									  <th style="width:20%;">Date</th>  
									  <th style="width:6%;">Preview</th>										  

                                        
								  </tr>
							  </thead>   
                <?php         
                $db->go("SELECT * FROM notify WHERE status = 1 ORDER BY tanggal DESC LIMIT $offset , $site_hal");
                while ($dat = $db->fetchArray()) {
                    if (strlen($dat['url']) > 45) {
                        $url = substr($dat['url'], 0, 45) . "...";
                    } else {
                        $url = $dat['url'];
                    } 
			               $getHome = parse_url($dat['url'], PHP_URL_PATH);
			               if($getHome=="/" || $getHome == "/index.php" || $getHome == "/index.html" || $getHome == "/index.htm" || $getHome == "" ) {
                			$cekHome = 'H';
			} else {
			$cekHome = '';
			}
      if ($ip = $dat['serip']) {
			$ipdetail = json_decode(file_get_contents("http://ip-api.com/json/$ip"));
			$cn = $ipdetail->country;
			$cc = $ipdetail->countryCode;
			}
			if ($dat['type'] == "1" && $dat['status'] == "1") {
			$cekSpecial = '<i class="fa fa-star"></i>';
			}
			else {
			$cekSpecial = '<i class="fa fa-star-o"></i>';
			}					
					
			
 if ($dat['mass'] == 1) {
$mass = "M";
} else {
$mass = "";
}
                       $hackk = $dat['hacker']
					   






                    ?>
<?php
					
$link = $url;
$klasor = parse_url($link, PHP_URL_PATH); 
$klasorlinki = substr($klasor, 1); 

$linkikir = $url;
$kiralim = parse_url($linkikir);
$kirilanlink = $kiralim['host'];

$linkturual = $url;
$linkimizinturu = parse_url($linkturual);
$alturubakalim = $linkimizinturu['scheme'];

?>
                    <tbody>
                        <tr>
                            <td><a href="<?php echo url_site; ?>arama/<?php echo $dat['hacker']; ?>"><?php echo $dat['hacker']; ?></a></td>  
							<td><img src='/flags/<?php echo $cc; ?>.png' alt='<?php echo $cn; ?>' title='<?php echo $cn; ?>'></center></td>
							<td><?php echo $alturubakalim; ?></td>
                            <td><a href="<?php echo $dat['url']; ?>"><?php echo $kirilanlink; ?></a></td>
                            <td><?php echo $klasorlinki; ?></center></td>  
                            <td><?php echo $dat['serip']; ?></td>								
                            <td><?php echo $dat['tanggal']; ?></td>		
                            <td>
                            <a href="<?php echo url_site; ?>mirror/<?php echo $dat['id']; ?>"><i class="icon-search"></i></a>
                            </td>
                        </tr>
                    </tbody>
<?php } ?>
    </table>
</div>
</div>
    <div class="row">
        <div class="col-sm-12">
            <div class="pull-right">
                <div class="dataTables_paginate paging_bootstrap pagination">
                    <ul class="pagination pagination-sm">
                        <?php
                        $db->go("SELECT COUNT(*) AS jumData FROM notify WHERE status = 1");
                        $data = $db->fetchArray();

                        $jumData = $data['jumData'];
                        $jumPage = ceil($jumData / $site_hal);
                        // menampilkan link previous

                        if ($noS > 1)
                            echo "<li class='prev'><a href='".url_site."archive/" . ($noS - 1) . "'>&laquo; prev</a></li>";

                        for ($page = 1; $page <= $jumPage; $page++) {
                            if ((($page >= $noS - 3) && ($page <= $noS + 3)) || ($page == 1) || ($page == $jumPage)) {
                                if (($showPage == 1) && ($page != 2))
                                    echo "";
                                if (($showPage != ($jumPage - 1)) && ($page == $jumPage))
                                    echo "";
                                if ($page == $noPage)
                                    echo " <li><a>" . $page . "</a></li> ";
                                else
                                    echo " <li><a href='".url_site."archive/" . $page . "'>" . $page . "</a></li> ";
                                $showPage = $page;
                            }
                        }

                        // menampilkan link next

                        if ($noS < $jumPage)
                            echo "<li class='next'><a href='".url_site."archive/" . ($noS + 1) . "'>next &raquo;</a></li>";
                        ?>
                    </ul>
                </div></div></div>
            </div>
            <div class="clearfix"></div>
        </div>
<?php
include('footer.php');
?>