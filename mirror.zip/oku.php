
<?php 
include "header.php";
?> 







<?php

$parametreler = strtolower($_SERVER['QUERY_STRING']); //Adres satırından gelen tüm sorguları aldık.
$yasaklar="%¿¿'¿¿`¿¿insert¿¿concat¿¿delete¿¿join¿¿update¿¿select¿¿\"¿¿\\¿¿<¿¿>¿¿tablo_adim¿¿kolon_adim"; 
$yasakla=explode('¿¿',$yasaklar);
$sayiver=substr_count($yasaklar,'¿¿');
$i=0;
while ($i<=$sayiver) {
if (strstr($parametreler,$yasakla[$i])) {
header("location:yasak.php");
exit;
}
$i++;	
}
if (strlen($parametreler)>=90) {
header("location:yasak.php");
exit;	
}

$parametreler = strtolower($_SERVER['QUERY_STRING']);
$yasaklar="%¿¿'¿¿`¿¿insert¿¿concat¿¿delete¿¿join¿¿update¿¿select¿¿\"¿¿\\¿¿<¿¿>¿¿tablo_adim¿¿kolon_adim"; 
$yasakla=explode('¿¿',$yasaklar);
$sayiver=substr_count($yasaklar,'¿¿');
$i=0;
while ($i<=$sayiver) {
if (strstr($parametreler,$yasakla[$i])) {
header("location:yasak.php");
exit;
}
 
$i++;	
}
 
if (strlen($parametreler)>=90) {
header("location:yasak.php");
exit;	
}

$id = $_GET['okuyak'];
$id = NoSqli($id);
$db->go("SELECT * FROM duyurular where id=$id");
$verial = $db->fetchArray();
		
?>



<div class="container">

<ul class="breadcrumb">
	<li>
		<i class="icon-home"></i>
		<a>Home</a> 
		<i class="icon-angle-right"></i>
	</li>
	<li><a href="">Duyuru</a></li>
</ul>


        <div class="panel panel-default">
            <div class="panel-heading"><?php echo $verial['baslik']; ?></div>
						  <div class="panel-body">
							<?php echo $verial['icerik']; ?>
</div>
												  		
					  </div>

				</div><!--/span-->	
			</div>

</div>

<?php
include "footer.php"; 
?>