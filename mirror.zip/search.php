<?php
include('header.php');
?>
<div class="container">

<ul class="breadcrumb">
	<li>
		<i class="icon-home"></i>
		<a>Home</a> 
		<i class="icon-angle-right"></i>
	</li>
	<li><a href=""><i class="icon-search"></i> Search</a></li>
</ul>


        
							  
							  
								




			
                                      
						
            <?php
            $value = NoSqli($_GET['search']);
            if ((isset($value)) AND ($value <> "")) {

                $db->go("SELECT * FROM notify WHERE hacker LIKE '%$value%'");
                $hit1 = $db->numRows();

			?>
			
			<div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default" id="tables">
                    <div class="panel-heading"><i class="icon-search"></i> Arama Sonuçları</b>
                    </div>
					<div class="panel-body">
					<div class="btn-group btn-group-justified">
							<a class="btn btn-primary"><i class="fa fa-archive"></i> Total Results : <?php echo $hit1 ?></a>
					</div>
						<table class="table table-hover">
							<thead>
							<tr>
									  <th style="width:15%;">Hacker</th>
									  <th style="width:5%;">Country</th>
									  <th style="width:5%;">Scheme</th>
									  <th style="width:20%;">Host</th>
									  <th style="width:20%;">Path</th>  
									  <th style="width:20%;">Query</th> 
									  <th style="width:25%;">Tarih</th>
									  <th style="width:5%;">izle</th>										  

                                        
								  </tr>
							  </thead>   
							  <tbody>
							  
			<?php
                if ($hit1 > 0) {
                    $db->go("SELECT * FROM notify WHERE hacker LIKE '%$value%'");
                    while ($data = $db->fetchArray()) {
			$ip = $data['serip'];	
			$ipdetail = json_decode(file_get_contents("http://ip-api.com/json/$ip"));
			$cn = $ipdetail->country;
			$cc = $ipdetail->countryCode;
						
						echo '<tr>
									<td><a href="search.php?search=' . $data['hacker'] . '">' . $data['hacker'] . '</a></td>
									<td class="center" style="text-align: center"><img src="/flags/' . $cc . '.png" style="height:25px;"></td>
									<td class="center">http</td>
									<td class="center"><a href="' . $url_site . 'mirror/' . $data['id'] . '">' . $data['url'] . '</a></td>
									
									<td class="center">/</td>
									<td class="center"></td>
									<td class="center">' . $data['tanggal'] . '</td>
									<td class="center"><a href="' . $url_site . 'mirror/' . $data['id'] . '"><i class="icon-search"></i></a></td>

								
                                      
								</tr>';
								
                    }
                } else {
                    echo '<p><strong>Data tidak ditemukan di database notify</strong></p>';
                }
				
				
                ?>
				
				</tr>
								
								
								
							</tbody>
						</table>

					</div>
                </div>
            </div>




				
			

				
				
		</div>

</div>

            </div>
        </div>
    </div>
    <?php
} else {
    TambahPesan("Anda belum menginputkan data apapun");
    Redirect('index');
}
include('footer.php');
?>

		