<?php include "header.php"; ?>
	<br><br><br><br>
	<div class="container">
	<ul class="breadcrumb">
	<li>
		<i class="icon-home"></i>
		<a>Home</a> 
		<i class="icon-angle-right"></i>
	</li>
	<li><a><i class="icon-edit"></i>  Notify / Report</a></li>
</ul>


	<div class="row">
		<div class="col-lg-12">
			<div class="panel panel-default" id="forms">
				<div class="panel-heading"><i class="icon-edit"></i>  Notify / Report ss
				</div>
				<div class="panel-body">
					<a href="mass.notify"><i class="fa fa-plus-circle"></i> MASS /  Multiple Report Site</a><br>
                    <form action="not_act.php" method="post" role="form">
                        <h1><b>Single Notify</b></h1>

                                <div class="form-group">
                                    <label>Hacker (Cyber Name)</label>
                                    <input type="text" class="form-control" placeholder="Nick Name" style="width: 200px;" name="hacker" onkeyup="valid(this)" onblur="valid(this)/>
									
                                </div>
                                <div class="form-group">
                                    <label>Team</label>
                                    <input type="text" class="form-control" placeholder="Team Name" style="width: 200px;" name="team" onkeyup="valid(this)" onblur="valid(this)">
                                </div>
                                <div class="form-group">
                                    <label>Domain</label>
                                    <input type="url" class="form-control" placeholder="http://example.com" style="width: 200px;" name="url" onkeyup="valid(this)" onblur="valid(this)">
                                </div>
                               <div class="form-group">
                                  <label>Proof of Concept (Now ll be displayed on mirror page)</label>
                                  <select class="form-control" name="poc" id="poc" style="width: 200px;" required="">
                                    <option value="">--------SELECT--------</option>
                                    <option value="known vulnerability (i.e unpatched system)">Known Vulnerability (i.e Unpatched System)</option>
                                    <option value="Undisclosed Vulnerability">Undisclosed Vulnerability</option>
                                    <option value="Configuration / Admin. Mistake">Configuration / Admin. Mistake</option>
                                    <option value="Brute Force Attack">Brute Force Attack</option>
                                    <option value="Social Engineering">Social Engineering</option>
                                    <option value="Web Server Intrusion">Web Server Intrusion</option>
                                    <option value="Web Server External Module Intrusion">Web Server External Module Intrusion</option>
                                    <option value="Mail Server Intrusion">Mail Server Intrusion</option>
                                    <option value="FTP Server Intrusion">FTP Server Intrusion</option>
                                    <option value="SSH Server Intrusion">SSH Server Intrusion</option>
                                    <option value="Telnet Server Intrusion">Telnet Server Intrusion</option>
                                    <option value="RPC Server Intrusion">RPC Server Intrusion</option>
                                    <option value="Shares Misconfiguration">Shares Misconfiguration</option>
                                    <option value="Other Server Intrusion">Other Server Intrusion</option>
                                    <option value="SQL Injection">SQL Injection</option>
                                    <option value="URL Poisoning">URL Poisoning</option>
                                    <option value="File Inclusion">File Inclusion</option>
                                    <option value="Other Web Application Bug">Other Web Application Bug</option>
                                    <option value="Remote Admin Panel Access Through Bruteforcing">Remote Admin Panel Access Through Bruteforcing</option>
                                    <option value="Remote Admin Panel Access Through Password Guessing">Remote Admin Panel Access Through Password Guessing</option>
                                    <option value="Remote Admin Panel Access Through Social Engineering">Remote Admin Panel Access Through Social Engineering</option>
                                    <option value="Remote Against The Admin/User (Password Stealing/Sniffing)">Remote Against The Admin/User (Password Stealing/Sniffing)</option>
                                    <option value="Access Credentials Through Man In The Middle Attack">Access Credentials Through Man In The Middle Attack</option>
                                    <option value="Remote Service Password Guessing">Remote Service Password Guessing</option>
                                    <option value="Remote Service Password Bruteforce">Remote Service Password Bruteforce</option>
                                    <option value="Rerouting After Attacking the Firewall">Rerouting After Attacking the Firewall</option>
                                    <option value="Rerouting After Attacking the Router">Rerouting After Attacking the Router</option>
                                    <option value="DNS Attack Through Social Engineering">DNS Attack Through Social Engineering</option>
                                    <option value="DNS Attack Through Cache Poisoning">DNS Attack Through Cache Poisoning</option>
                                    <option value="Cross-Site Scripting">Cross-Site Scripting</option>
                                    <option value="Not Available">Not Available</option>
                                </select>
                                </div>
                        <input type="hidden" name="k" value="<?php echo rand(11231,90012);?>"/>
                        <button class="btn btn-primary"><i class="fa fa-fw fa-lg fa-check-circle"></i> Report</button>
                    </form>    
                </div>
            </div>
        </div>
    </div>
</div>
<?php include "footer.php"; ?>