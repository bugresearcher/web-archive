<?php
$site_hal = site_hal;
if (isset($_GET['zone'])) {
    $noS = $_GET['zone'];
}
else
    $noS = 1;
$offset = ($noS - 1) * $site_hal;
?>


<div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default" id="tables">
                    <div class="panel-heading"><i class="icon-globe"></i> Latest Report
                    </div>
					<div class="panel-body">
						<table class="table table-hover">
							<thead>
							<tr>
									  <th>Name</th>
                        <th>Domain</th>
                        <th class="text-center">Country</th>
						<th class="text-center">Alexa</th>
                        <th class="text-center">IP</th>
                        <th class="text-center"><i class="fa fa-star"></i></th>
                        <th class="text-center">Time</th>
                        <th class="text-center">Preview</th>										  

                                        
								  </tr>
							  </thead>   
							  <tbody>
                <?php
                $db->go("SELECT * FROM notify WHERE status = 1 ORDER BY tanggal DESC LIMIT 5");
                while ($dat = $db->fetchArray()) {

                    if (strlen($dat['url']) > 45) {
                        $url = substr($dat['url'], 0, 45) . "...";
                    } else {
                        $url = $dat['url'];
                    }

			$getHome = parse_url($dat['url'], PHP_URL_PATH);
			if($getHome=="/" || $getHome == "/index.php" || $getHome == "/index.html" || $getHome == "/index.htm" || $getHome == "" ) {
			$cekHome = 'H';
			} else {
			$cekHome = '';
			}
            if ($ip = $dat['serip']) {
			$ipdetail = json_decode(file_get_contents("http://ip-api.com/json/$ip"));
			$cn = $ipdetail->country;
			$cc = $ipdetail->countryCode;
			}
			if ($dat['type'] == "1" && $dat['status'] == "1") {
			$cekSpecial = '<i class="fa fa-star"></i>';
			}
			else {
			$cekSpecial = '<i class="fa fa-star-o"></i>';
			}					
            if ($dat['mass'] == 1) {
            $mass = "M";
            } else {
            $mass = "";
            }
			
$alanadi = ''.$url.'';
$alexaverisi = simplexml_load_file('http://data.alexa.com/data?cli=10&url='.$alanadi);
$dunyasiralamasi = number_format( (int) $alexaverisi->SD->POPULARITY['TEXT'] );
$ulkekodumuz = $alexaverisi->SD->COUNTRY['CODE'];
$ulkeadi = $alexaverisi->SD->COUNTRY['NAME'];
$ulkesiralamasi = number_format( (int) $alexaverisi->SD->COUNTRY['RANK'] );
$veriyigetir1 = $dunyasiralamasi;
$veriyigetir2 = $ulkeadi;
$veriyigetir3 = $ulkesiralamasi;


                    ?>
                    <tbody>
                        <tr>
                            <td class="text-center">
                                <a href="search.php?search=<?php echo $dat['hacker']; ?>"><?php echo $dat['hacker']; ?></a></td>
                            <td lass="text-center"><a href="<?php echo url_site; ?>mirror/<?php echo $dat['id']; ?>"><?php echo $url; ?></a></td>
                  
                            <td class="text-center"><img src='/flags/<?php echo $cc; ?>.png' alt='<?php echo $cn; ?>' title='<?php echo $cn; ?>'></center></td>
							<td class="text-center"><?php echo $dunyasiralamasi; ?></center></td>
                            <td class="text-center"><?php echo $dat['serip']; ?></td>
                            <td class="text-center"><?php echo $cekSpecial; ?></td>
                            <td class="text-center"><?php echo $dat['tanggal']; ?></td>
                            <td class="text-center">
                                <a href="<?php echo url_site; ?>mirror/<?php echo $dat['id']; ?>"><i class="icon-search"></i> </a>
                            </td>
                        </tr>
                    </tbody>
<?php } ?>
      </table>
  </div>
</div>
</div>