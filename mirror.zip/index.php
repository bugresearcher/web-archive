<?php 
include "header.php";
?> 


<br>
<div class="jumbotron" style="margin-top:-55px;">
        <div class="jumbotron" style="margin-top:-55px;">
			<div class="container">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-archive fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
								<?php
                        $db->go("SELECT * FROM notify");
                        $data1 = $db->numRows();
                        ?> 
                                    <div class="huge"><?php echo $data1; ?></div>
                                    <div>Total Report</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-user fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
								<?php
                        $db->go("SELECT * FROM hacker");
                        $data = $db->numRows();
                        ?>
                                    <div class="huge"><?php echo $data; ?>
									  </div>
                                    <div>Attacker !</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-users fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
								 <?php
                        $db->go("SELECT * FROM team");
                        $data = $db->numRows();
                        ?>
                                    <div class="huge"><?php echo $data; ?></div>
                                    <div>Team !</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            
			
			  
			
			  <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-bullhorn fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
								<?php
                        $db->go("SELECT * FROM duyurular");
                        $data = $db->numRows();
                        ?>
                                    <div class="huge"><?php echo $data; ?>
									  </div>
                                    <div>News !</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			
					</div>
				</div>
			</div>
        </div>
		
<div class="col-md-12"><?php include "recent.php"; ?>
</div>



<div class="container">
        <div class="row">
            <div class="col-lg-6">								
                <div class="panel panel-default" id="tables">
                    <div class="panel-heading"><i class="icon-user"></i> Top 5 Hacker
                    </div>
					<div class="panel-body">
						<table class="table table-hover">
							<thead>
								  <tr>
								  	  <th>No</th>
                        <th>Name</th>
                        <th>Team Name</th>
                        <th>Total Deface</th>
                        <th>Special Deface</th>

                                        
								  </tr>
							  </thead>   
						

                <?php
                $db->go("SELECT * FROM hacker ORDER BY deface DESC LIMIT 5");
                $no = 1;
                while ($data = $db->fetchArray()) {
                    ?>
                    <tbody>
                        <tr>
                            <td><?php echo $no; ?></a></td>
                            <td class="text-center"><a href="search.php?search=<?php echo $data['hacker']; ?>"><?php echo htmlspecialchars($data['hacker']); ?></a></td>
                            <td class="text-center"><?php echo htmlspecialchars($data['team']); ?></td>
                            <td class="text-center"><?php echo $data['deface']; ?></a></td>
                            <td class="text-center"><?php echo $data['special']; ?></td>
                        </tr>
                    </tbody>
    <?php $no++;
} ?>
        </table>
    </div>
</div>
</div>

<div class="col-lg-6">	
                <div class="panel panel-default" id="tables">
                    <div class="panel-heading"><i class="icon-bullhorn"></i> News
                    </div>
					<div class="panel-body">
						<table class="table table-hover">
							<thead>
								  <tr>
								  	  <th>#News</th>
	       
								  </tr>
							  </thead>  
<?php
                $db->go("SELECT * FROM duyurular ORDER BY baslik DESC LIMIT 5");
                $no = 1;
                while ($data = $db->fetchArray()) {
                    ?>							  
							  <tbody>
							  	

								<tr>
									<td><a href="oku/<?php echo $no; ?>"><?php echo $data['baslik']; ?></a></td>
								</tr>
								
							</tbody>
							<?php $no++;
} ?>
						</table>
					</div>
                </div>
            </div>

<?php
include "footer.php"; 
?>