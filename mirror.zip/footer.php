</div>
<br><br><br><br><br><br>
<footer>
        <p>&copy; 2015 - Shadow-H | Mirror | Hack Zone | Hack Mirror | Shadow System <br><i class="fa fa-envelope"></i> <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="ff8d90908bbf92968d8d908dd297d1908d98">root@shadow-h.com</a></p>
		<span style="float:right;">
			| <a>hack forum</a>
			| <a>reklam ver</a>
			| <a>reklam ver</a>
		<span>
      </footer>
 <script src="/js/vendor/bootstrap.min.js"></script>
 <script src="/js/plugins.js"></script>
 </body>
 </html>