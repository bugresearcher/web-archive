






<?php  
$linkikir = 'https://google.com/dhasjkdas/sadsdds/sdda/sdads.html';
$kiralim = parse_url($linkikir);
echo $kiralim['scheme'];
?> 


             