<?php 
include "header.php";
?> 


<br><br><br><br><br><br><br>


<div class="container">
<ul class="breadcrumb">
	<li>
		<i class="icon-home"></i>
		<a >Ana Sayfa</a> 
		<i class="icon-angle-right"></i>
	</li>
	<li><a><i class="icon-legal"></i> Yasal Uyarı</a></li>
</ul>


<div class="row-fluid sortable ui-sortable">



        <div class="panel panel-default">
            <div class="panel-heading"><i class="icon-legal"></i> Yasal Uyarı</div>
						  <div class="panel-body">


					<p>Bu site adından da anlaşıldığı üzere 
bir yansıma sitesidir. web sitelerinin 
anlık görüntülerinin kayıt edilmesi ile oluşur. Bu nedenle site 
içersinde 
saldırı yapılmış veya istenmeyen görüntüler olabilir, Web 
Sayfaların anlık 
görüntülerini kullanıcılar tarafından eklenmektedir. Eklenen 
görüntülerden 
doğacak sorumluluklar, <b>shadow-h.com</b> e ait değildir. <b>shadow-h.com</b> 
tamamen 
kullanıcılardan topladığı kayıtları veritabanında tutar. </p>
<p><b>shadow-h.com</b> in yasal haklarınızı ihlal ettiğini 
düşünüyorsanız.
<a href"mailto:info@shadow-h.com"><b><span class="__cf_email__" data-cfemail="432a2d252c032e2a31312c316e2b6d2c3124">shadow-h.com</span></b></a> E-Mail ile 
iletişim 
kurduğunuz takdirde avukatlarımız, size bildiri yapacaklardır. 
Bilgilendirmeden 
yapılacak yasal işlemlerde <b>shadow-h.com</b> yasal sorumlulukları 
kullanıcıya aittir.
</p>
<p>Web sayfasını kullanan tüm kullanıcılar ekledikleri kayıtlardan 
sorumludur. 
<b>shadow-h.com</b> eklenen içeriklerden sorumluluk kabul etmez. kayıt 
ekleyen tüm 
kullanıcılar, bu bildiriyi okumuş ve kabullenmiş 
sayılırlar.</p>

					
					</div>
				</div>
			
			</div>
			</div>

				</div><!--/span-->
</div>
					  
</div>


<?php
include "footer.php"; 
?>