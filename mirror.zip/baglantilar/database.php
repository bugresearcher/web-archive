<?php
error_reporting(0);
$server = 'localhost';
$username = 'root';
$password = '';
$database = 'mirror';
mysql_query("SET COLLATION_CONNECTION = 'utf8_turkish_ci'");
try{
	$conn = new PDO("mysql:host=$server;dbname=$database;", $username, $password);
} catch(PDOException $e){
	die( "Bağlantı sağlanamadı: " . $e->getMessage());
}