<?php 
ob_start();
/**
 * Rama Zeta Configuration Files - Thanks to allah , my family , and my friends :)
 * File Component
 */
function readmoreberita($string,$id){ 
    
    if(strlen($string) > 250){
        $pecah = substr($string, 0, 300); 
        $string = $pecah . "<br/><div class='pull-right'><a href='news.php?id=".$id."' class='btn btn-primary'>Read More</a></div>";
    } else {
        $string;
    }
    return $string; 
    
}
function readmoreevents($string,$id){ 
    
    if(strlen($string) > 250){
        $pecah = substr($string, 0, 300); 
        $string = $pecah . "<br/><div class='pull-right'><a href='events.php?id=".$id."' class='btn btn-primary'>Read More</a></div>";
    } else {
        $string;
    }
    return $string; 
    
}
function special_telor($nilai){
    if($nilai == '0'){
        echo '<i class="icon-thumbs-up"></i>';
    } else if($nilai == '1'){
        echo '<i class="icon-star"></i>';
    } else {
        echo '<i class="icon-thumbs-down"></i>';
    }
}
function cek_konten($teks) {
    $penting = array("hacker","hacked","cracked","tusboled","owned","Owned","touched","cracker","heker");
    $hasil = 1;
    $jml_kata = count($penting);
    
    for ($i=0;$i<$jml_kata;$i++){
        if (stristr($teks,$penting[$i])){ 
            $hasil=0; }
 
        }
    return $hasil;
 }
 
function NoSqli($data){
  $filter_sql = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter_sql;
}
function Alert($alert){
    echo"<script>alert('".$alert."');</script>";
}
function DataAda($data){
    if(isset($data)){
        echo $data;
    }
}
function KhususAdmin()
{
    if(!isset($_SESSION['']['AUTH_ADMIN_LOGGED']))
    {
        TambahPesan('Untuk mengakses halaman ini , anda perlu login sebagau Administrator');
        Redirect('index.php');
    }
}

function IsAdminLogin()
{
    return isset($_SESSION['']['AUTH_ADMIN_LOGGED']);
}
function AdminLogout()
{
    unset($_SESSION['']['AUTH_ADMIN_LOGGED']);
    TambahPesan('Anda berhasil logout');
}

function Redirect($url = '')
{
    header('Location: '.$url);
    exit();
}

function BuildUrl()
{
    return $_SERVER['PHP_SELF'].(isset($_SERVER['QUERY_STRING'])&&!empty($_SERVER['QUERY_STRING'])?'?'.$_SERVER['QUERY_STRING']:'');
}

function TambahPesan($msg = '')
{
    $_SESSION['']['PSN'] = !isset($_SESSION['']['PSN']) ? $msg : $msg.'<br/>'.$_SESSION['']['PSN'];
}

function TampilPesan($return_string = false)
{
    if(isset($_SESSION['']['PSN']))
    {
        $msg = trim($_SESSION['']['PSN']);
        unset($_SESSION['']['PSN']);
        
        if($return_string)
            echo '<div class="alert alert-success alert-dismissable">
                    <i class="icon-remove-sign"></i>'.$msg.'
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  </div>';
        else
            echo '<div class="alert alert-danger alert-dismissable">
                    <i class="icon-remove-sign"></i>'.$msg.'
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  </div>';
    }
}
function CobaLogin($uname = '', $pass = '')
{
    if($uname == admin_uname && $pass == admin_password)
    {
        $_SESSION['']['AUTH_ADMIN_LOGGED'] = true;
        Redirect('admin.php');
    }
    
    return false;
}

function get_curl_remote_ips($fp) {
    rewind($fp);
    $str = fread($fp, 8192);
    $regex = '/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/';
    if (preg_match_all($regex, $str, $matches)) {
        return array_unique($matches[0]);  // Array([0] => 74.125.45.100 [2] => 208.69.36.231)
    } else {
        return false;
    }
}
?>