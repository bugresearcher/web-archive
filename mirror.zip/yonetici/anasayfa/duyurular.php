	<?php
	
session_start();
ob_start();
require 'baglantilar/database.php';

if( isset($_SESSION['yonetici']) && !empty($_SESSION['yonetici']) ){

	$records = $conn->prepare('SELECT * FROM yoneticiler WHERE id = :id');
	$records->bindParam(':id', $_SESSION['yonetici']);
	$records->execute();
	$results = $records->fetch(PDO::FETCH_ASSOC);

	$user = NULL;

	if( count($results) > 0){
		$user = $results;
	}

}
else
{
	header("Location: giris.php");
	die();
}
?>
<div class="left-2 col-sm-6">
                        <a><div class="panel panel-default memory-select">
                            <div class="panel-body">
                                <p class="memory-amount" style="margin-bottom: 0;"><strong>Duyuru Yönetimi</strong><br>Listedeki Duyurulara Tıklayarak Duyuruları Duzenliyebilirsiniz!</p>
                            </div>
                        </div></a>
                    </div>
                    <div class="right-2 col-sm-6">
                        <a href="?sayfa=duyuruekle"><div class="panel panel-default memory-select">
                            <div class="panel-body">
                                <p class="memory-amount" style="margin-bottom: 0;"><strong>Duyuru Ekleyebilirsiniz</strong><br>Buraya Tıklayarak Duyuru Ekliyebilirsiniz !</p>
                            </div>
                    </div></a>
                    </div>

<?php 

$vericek = $conn -> prepare("SELECT * FROM duyurular");
$vericek-> execute();

?>

<?php
if (isset($_GET['numara'])) {
$numaras = $_GET['numara'];	
$silyorums = $conn -> prepare("DELETE FROM duyurular where id = :id");
$silyorums->bindParam(':id', $_GET['numara']);
$silyorums-> execute();
if($silyorums){
 
echo '<meta http-equiv="refresh" content="2;URL=?sayfa=duyurular"><div class="alert alert-dismissible alert-success">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>Duyuru Başarı İle Silindi. 2 Saniye İçinde Yönlendiriliyorsunuz</strong>
                </div>';
}else{
 
echo "başarısız";
}  
} 
?> 

<?php 
        while ($veriyigoster = $vericek -> fetch(PDO::FETCH_ASSOC)){
          echo '<table class="table table-striped">
  

        <tbody>

                                 
                        <tr>
                            <td><a href="?sayfa=duyuruduzenle&id='.$veriyigoster["id"].'"><div class="label label-danger">Duyuru Yönetimi!</div> &nbsp;<strong>Duyuru Adı: '.$veriyigoster["baslik"].'</strong> </a></td>
                            <td><span style="float: right;"><a href="?sayfa=duyurular&numara='.$veriyigoster['id'].'" class="btn btn-success btn-sm">Hemen Bu Duyuruyu Sil</a></td>
                        </tr>

                                                
                        

                             '; 
        }

       ?>



 




   </div>
  
    </div>
  </div>
 </div>


					
