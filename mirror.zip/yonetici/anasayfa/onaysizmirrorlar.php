	<?php


session_start();
ob_start();
require 'baglantilar/database.php';

if( isset($_SESSION['yonetici']) && !empty($_SESSION['yonetici']) ){

	$records = $conn->prepare('SELECT * FROM yoneticiler WHERE id = :id');
	$records->bindParam(':id', $_SESSION['yonetici']);
	$records->execute();
	$results = $records->fetch(PDO::FETCH_ASSOC);

	$user = NULL;

	if( count($results) > 0){
		$user = $results;
	}

}
else
{
	header("Location: giris.php");
	die();
}
?>
<div class="left-2 col-sm-6">
                        <a href="?sayfa=onaysizmirrorlar&onayla=1"><div class="panel panel-default memory-select">
                            <div class="panel-body">
                                <p class="memory-amount" style="margin-bottom: 0;"><strong>Tüm Mirror Yönetimi</strong><br>Buraya Tıklayarak Tüm Mirrorları Onaylıyabilirsiniz !</p>
                            </div>
                        </div></a>
                    </div>
                    <div class="right-2 col-sm-6">
                        <a><div class="panel panel-default memory-select">
                            <div class="panel-body">
                                <p class="memory-amount" style="margin-bottom: 0;"><strong>Tekli Mirror Onaylama</strong><br>Listedeki Onaylamak İstediğiniz Mirrorlara Tıklayarak Onayliyabilirsiniz!</p>
                            </div>
                    </div></a>
                    </div>

<?php 

$vericek = $conn -> prepare("SELECT * FROM notify");
$vericek-> execute();

?>

<?php
if (isset($_GET['tekli'])) {
$getir = $_GET['tekli'];
$query = $conn->prepare("UPDATE notify SET
status = :yeni_kadi
WHERE id = :eski_kadi");
$update = $query->execute(array(
     "yeni_kadi" => "1",
     "eski_kadi" => $getir
));

if($update){
 
echo '<meta http-equiv="refresh" content="2;URL=?sayfa=onaysizmirrorlar">
 <div class="col-md-9">
                  <div class="alert alert-dismissible alert-success">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>Mirror Başarı İle Onaylandi . 2 Saniye İçinde Yönlendiriliyorsunuz</strong>
                </div>';
}else{
 
echo "başarısız";
}  
} 
?> 

<?php
if (isset($_GET['onayla'])) {

$query = $conn->prepare("UPDATE notify SET
status = :yeni_kadi
WHERE status = :eski_kadi");
$update = $query->execute(array(
     "yeni_kadi" => "1",
     "eski_kadi" => "0"
));

if($update){
 
echo '<meta http-equiv="refresh" content="2;URL=?sayfa=onaysizmirrorlar">
 <div class="col-md-9">
                  <div class="alert alert-dismissible alert-success">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>Tüm Mirrorlar Başarı İle Onaylandi . 2 Saniye İçinde Yönlendiriliyorsunuz</strong>
                </div>';
}else{
 
echo "başarısız";
}  
} 
?> 


<?php
if (isset($_GET['numara'])) {
$numaras = $_GET['numara'];	
$silyorums = $conn -> prepare("DELETE FROM notify where id = :id");
$silyorums->bindParam(':id', $_GET['numara']);
$silyorums-> execute();
if($silyorums){
 
echo '<meta http-equiv="refresh" content="2;URL=?sayfa=onaysizmirrorlar">
 <div class="col-md-9">
<div class="alert alert-dismissible alert-success">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>Mirror Başarı İle Silindi. 2 Saniye İçinde Yönlendiriliyorsunuz</strong>
                </div>';
}else{
 
echo "başarısız";
}  
} 
?> 

<?php 

$numara1 = '0';
$verial1 = $conn -> prepare("SELECT * FROM notify WHERE status = :status");
$verial1->bindParam(':status', $numara1);
$verial1-> execute();
        while ($veriyigoster = $verial1 -> fetch(PDO::FETCH_ASSOC)){
          echo ' 
          <table class="table table-striped">
  

        <tbody>

                                 
                        <tr>
                            <td><a"><div class="label label-danger">Mirror Yönetimi!</div> &nbsp;<strong>Hacker Adı: '.$veriyigoster["hacker"].' - Link Adi: '.$veriyigoster["url"].'</strong> </a></td>
                            <td><span style="float: right;"><a href="?sayfa=onaysizmirrorlar&tekli='.$veriyigoster['id'].'" class="btn btn-success btn-sm">Onayla</a> <a href="?sayfa=onaysizmirrorlar&numara='.$veriyigoster['id'].'" class="btn btn-success btn-sm">Hemen Sil</a> </td>
                        </tr>
          '; 
        }

       ?>


 




   </div>
  
    </div>
  </div>
 </div>


					
