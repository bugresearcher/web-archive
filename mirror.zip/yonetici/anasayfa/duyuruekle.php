	<?php
	
session_start();
ob_start();
require 'baglantilar/database.php';

if( isset($_SESSION['yonetici']) && !empty($_SESSION['yonetici']) ){

	$records = $conn->prepare('SELECT * FROM yoneticiler WHERE id = :id');
	$records->bindParam(':id', $_SESSION['yonetici']);
	$records->execute();
	$results = $records->fetch(PDO::FETCH_ASSOC);

	$user = NULL;

	if( count($results) > 0){
		$user = $results;
	}

}
else
{
	header("Location: giris.php");
	die();
}
?>


<?php
if (isset($_POST["Gonder"])) {
	
$baslik = $_POST['baslik'];
$icerik = $_POST['icerik'];
$gonder = $conn -> prepare("INSERT INTO duyurular SET baslik=:baslik, icerik=:icerik");
$gonder->bindParam(':baslik', $baslik);
$gonder->bindParam(':icerik', $icerik);
$gonder->execute();

            
			
if($gonder){
 
echo '<meta http-equiv="refresh" content="2;URL=?sayfa=duyurular"><div class="alert alert-dismissible alert-success">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <strong>Duyuru Başarı İle Silindi. 2 Saniye İçinde Yönlendiriliyorsunuz</strong>
                </div>';
 
}else{
 
echo "başarısız";
 
}
}
?>



 
<div class="col-md-12">

       <div class="panel panel-default" style="margin-bottom:30px;">
         <div class="panel-heading" style="margin-bottom:5px;background:#fff;border-color:#34495e;color:#34495e">Duyuru Ekle</div>

          <div class="panel-body" style="padding:15px 15px 15px 15px;">

  

        
     <form action="" method="post">

     <div class="message"></div>


     <div class="deploy">
	 
<div class="form-group">
                     <label for="inputEmail3" class="">Baslik Adi</label>
                     <input type="text" name="baslik" class="form-control" id="baslik" placeholder="Eklemek İstediğiniz Duyuru Basligi">				
                  </div>
	 
<div class="form-group">
                     <label for="inputEmail3" class="">Baslik İcerigi</label>
                     <input type="text" name="icerik" class="form-control" id="icerik" placeholder="Eklemek İstediğiniz Duyuru İcerigi">				
                  </div>
        
          


         
         
        

         
           


       </div>   

 <hr>
  <a href="?sayfa=anasayfa" class="btn btn-danger pull-left">
         Geri Dön
  </a>
  <button type="submit" name="Gonder" class="btn btn-success pull-right">
         Duyuruyu Ekle
  </button>
</div>


</div>
   
</form>



   


					
