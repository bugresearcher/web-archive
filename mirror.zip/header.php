<?php include('inc/config.php'); 
session_start();
?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> 
<html class="no-js"  lang="en"> <!--<![endif]-->
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php echo site_title; ?> - Go To Hell</title>
        <meta name="description" content="Mirror Deface | Unrestricted information | professional mirror platform | Deface Notify Mirror | Notify Defacements | Ind Cyber Portal | Mirror Service | Mass Notifier | Add Deface | Add Attack | Cyber Community | Add your Deface | Hack Zone | Cyber Community">
        <meta name="viewport" content="width=device-width">
        <meta name="description" content="Shadow-H Mirror is a Site to Save Defacement And All Hacker Hacktivities And Store Unrestertied Info Of Hackers !,- A global view to the world with a stress on the ITsec, pakistani, Notifier, Add your Deface , Deface, Hacked , Report Your Attack, Hackers, Ranking , Hacker, Attackers, Mirror, Web, Zone, India Web Hack, Russia, Turkey, USA, Got, Who, Pro, Cyber, Media">
        <meta content="Aeiwi, Alexa, AllTheWeb, AltaVista, AOL Netfind, Anzwers, Canada, DirectHit, EuroSeek, Excite, Overture, Go, Google, HotBot. InfoMak, Kanoodle, Lycos, MasterSite, National Directory, Northern Light, SearchIt, SimpleSearch, WebsMostLinked, WebTop, What-U-Seek, AOL, Yahoo, WebCrawler, Infoseek, Excite, Magellan, LookSmart, bing, CNET,  Googlebot" name="search engines">
        <meta name="keywords" content="SHADOW-H, MirrorDB, SHADOW-H, SHADOW-H, hacker course,  seminar,seminario,security seminar,security course,securityfocus,penetration test,antivirus,antispam,hack inside,defacement,defacements,hacker,hackers,cracker,crackers,defacer,defacers,security,advisory,advisories,news,it,itsec,information,technology,defaced,attacks,cybercrime,attacks archive,attack,cyberterrorism,sql injection,buffer overflow,stack overflow,heap overflow,file inclusion,directory traversal, terrorism, counter terrorism, intelligence,geopolitic, Add Mirror, Notify Mirror, ZoneDB, HackDB, ZoneH, Hackers, Mirror, Deface, HackerZone, Add Notify, Mirror Zone, WebNotify,Skype Resolver,pakistani, Notifier, Add , Deface, Hacked , Report Your Attack, Hackers, Ranking , Hacker, Attackers, Mirror, Web, Zone, India Web Hack, Russia, Turkey, USA, Got, Who, Pro, Cyber, Media, Mass Deface , Notify Mass Defacements, Notify Mass Defacemnts, Notify mass Deface, Mass Notify Script, zone-db.com mass notify script,  Defacements, War,zone kayit,deface add, add, hack-h, hack add, Mirror Kayit, Zone Kayit ,Zone Kaydet ,Deface Kayit , mirror kayit,mirror zone,deface kayit,">
		<link href="<?php echo url_site; ?>theme.css" rel="stylesheet" media="screen">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<link href="https://mirror-h.org/templates/dark/css/font-awesome.min.css" rel="stylesheet">
	<link href="https://mirror-h.org/templates/dark/css/font-awesome-ie7.min.css" rel="stylesheet">
        <script src="<?php echo url_site; ?>js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    <body>
	<nav class="navbar navbar-inverse navbar-fixed-top " role="navigation">
	<div class="container">
	  <!-- Brand and toggle get grouped for better mobile display -->
	  <div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
		  <span class="sr-only">Toggle navigation</span>
		  <span class="icon-bar"></span>
		  <span class="icon-bar"></span>
		  <span class="icon-bar"></span>
		</button>
       <a class="navbar-brand"><img src="https://resmim.net/f/Y8pGVu.png?nocache" height="35" title="SHADOW-H | Mirror | Hack Zone | Hack Mirror | Shadow System" alt="SHADOW-H | Mirror | Hack Zone | Hack Mirror | Shadow System"></a>
	  </div>
            
           
				  <div class="collapse navbar-collapse navbar-ex1-collapse">
		<ul class="nav navbar-nav">
						<li><a href="<?php echo url_site; ?>index.php"><i class="icon-home"></i> <b>HOME</b></a></li>
						<li><a href="<?php echo url_site; ?>single.notify"><i class="icon-edit"></i> <b>Notify / Report</b></a></li>
						<li><a href="<?php echo url_site; ?>mass.notify"><i class="fa fa-plus-circle"></i> <b>MASS / Multi</b></a></li>
						<li><a href="<?php echo url_site; ?>archive/1"><i class="fa fa-archive"></i> <b>Archive</b></a></li>						
						<li><a href="<?php echo url_site; ?>ranked/1"><i class="icon-user"></i> <b>Activist</b></a></li>
						<li><a href="<?php echo url_site; ?>descalimer.php/"><i class="icon-legal"></i> <b>Descalimer</b></a></li>
					
            </ul>
		</div><!-- /.navbar-collapse --> 
	</div>	
</nav>
             <br><br><br><br>
			 <div class="row-fluid sortable ui-sortable">
<div class="span12">

		

		
			<?php echo TampilPesan(); ?>
		
		


</div>
</div>
			 