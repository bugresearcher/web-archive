<?php
include('header.php');
$id = NoSqli($_GET['id']);
$db->go("SELECT * FROM notify WHERE id = '$id'");

$control = $db->numRows();

if ($control == 0) {
    TambahPesan("Catatan tidak ada. Silahkan periksa kembali");
    Redirect('/archive.html?search=1');
} else {
    $db->go("SELECT * FROM notify WHERE id = '$id'");
    $mirror = $db->fetchArray();
    ?>
    <center><h3> View <span class="fa fa-eye"></span> Mirror : <strong>
        <?php echo'' . $mirror['url'] . ' ' ?></strong>   </h3></center>
      <?php
        if ($ip = $mirror['serip']) {
           	$ipdetail = json_decode(file_get_contents("http://ip-api.com/json/$ip"));
			$cn = $ipdetail->country;
			$cc = $ipdetail->countryCode;
			}
          ?>
    <section >
	<div class="container">
<div class="panel panel-default">
                    <div class="panel-heading">
											<div class="panel-body">
		<div class="col-lg-6">				
		<table width="100%">
			<tr>
				<td class="span3"><i class="icon-link"></i> WEB URL</td>
				<td class="span9">: <a href="<?php echo' ' . htmlspecialchars($mirror['url']) . ' ' ?>" target="_blank"><?php echo' ' . htmlspecialchars($mirror['url']) . ' ' ?></a></td>
			</tr>
			<tr>
				<td class="span3"><i class="icon-globe"></i> Location</td>
				<td class="span9">: <a><img src="/flags/<?php echo $cc; ?>.png" style="height:20px;"> <?php echo $cnn; ?></a></td>
			</tr>
			<tr>
				<td class="span3"><i class="icon-paper-clip"></i>  IP</td>
				<td class="span9">: <a><?php echo' ' . $mirror['serip'] . ' ' ?></a></td>
			</tr>
			<tr>
				<td class="span3"><i class="icon-qrcode"></i> Web Server</td>
				<td class="span9">: <a>Apache</a></td>
			</tr>
		</table>
		</div>
		
			<div class="col-lg-6">				
		<table width="100%">
			<tr>
				<td class="span3"><i class="icon-user"></i> Attacker</td>
				<td class="span9">: <a><?php echo' ' . htmlspecialchars($mirror['hacker']) . ' ' ?></a></td>
			</tr>
			<tr>
				<td class="span3"><i class="icon-plus"></i> PoC</td>
				<td class="span9">: <?php echo' ' . htmlspecialchars($mirror['poc']) . ' ' ?></td>
			</tr>
			<tr>
				<td class="span3"><i class="icon-calendar"></i> Date</td>
				<td class="span9">: <?php echo' ' . $mirror['tanggal'] . ' ' ?></td>
			</tr>
			<tr>
				<td class="span3"><i class="icon-check"></i> Report type</td>
				<td class="span9">: Standart</td>
			</tr>
		</table>
		</div>
						
				
			</div>
		<div class="container-fluid-full">
		<div class="row-fluid">
		<iframe src="<?php echo url_site; ?>inc/chack.php?id=<?php echo $_GET['id']; ?>" style="width: 100%;min-height: 600px;background: #FFFFFF;border: 1px solid #250000;" sandbox="allow-same-origin allow-scripts allow-forms"></iframe>
		
		</div><!--/.fluid-container-->
	
			<!-- end: Content -->
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->
		

	
	<div class="clearfix"></div>
	
</div>
</div>
<?php } ?>
<?php include "footer.php"; ?>