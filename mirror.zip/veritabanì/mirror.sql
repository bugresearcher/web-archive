/*
 Navicat MySQL Data Transfer

 Source Server         : dbem
 Source Server Type    : MySQL
 Source Server Version : 100134
 Source Host           : localhost:3306
 Source Schema         : mirror

 Target Server Type    : MySQL
 Target Server Version : 100134
 File Encoding         : 65001

 Date: 28/03/2019 14:41:26
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for duyurular
-- ----------------------------
DROP TABLE IF EXISTS `duyurular`;
CREATE TABLE `duyurular`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `baslik` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `icerik` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for hacker
-- ----------------------------
DROP TABLE IF EXISTS `hacker`;
CREATE TABLE `hacker`  (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `hacker` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `team` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `deface` int(5) NOT NULL,
  `special` int(5) NOT NULL,
  `onholds` int(5) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `team`(`team`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for notify
-- ----------------------------
DROP TABLE IF EXISTS `notify`;
CREATE TABLE `notify`  (
  `id` int(35) NOT NULL AUTO_INCREMENT,
  `hacker` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `url` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `content` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tanggal` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  `type` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `hit` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `regip` varchar(35) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `serip` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `poc` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for setting
-- ----------------------------
DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting`  (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `subtitle` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `logo` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `footer` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `description` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `jum_hal` int(3) NOT NULL,
  `contact_email` varchar(25) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of setting
-- ----------------------------
INSERT INTO `setting` VALUES (1, 'Mirror Archive', 'Illegal Information', '/', 'Copyright &copy; 2017', 'Mirror Archive is a powerful script to make mirror hacking website . Made In Indonesia', 15, 'admin@admin.com');

-- ----------------------------
-- Table structure for team
-- ----------------------------
DROP TABLE IF EXISTS `team`;
CREATE TABLE `team`  (
  `team` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `member` int(15) NOT NULL,
  `tot_deface` int(15) NOT NULL,
  `durum` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  PRIMARY KEY (`team`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for uadmin
-- ----------------------------
DROP TABLE IF EXISTS `uadmin`;
CREATE TABLE `uadmin`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `uname` varchar(50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `password` varchar(250) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `dob` date NOT NULL,
  `photo` varchar(150) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `act_code` varchar(150) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for yoneticiler
-- ----------------------------
DROP TABLE IF EXISTS `yoneticiler`;
CREATE TABLE `yoneticiler`  (
  `id` int(11) NOT NULL,
  `alanid` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `kullaniciadi` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `password` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
  `adiniz` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `aciklama` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE = MyISAM CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of yoneticiler
-- ----------------------------
INSERT INTO `yoneticiler` VALUES (1, '', 'deneme', 'test@gmail.com', '$2y$10$F3cygOsQz3Mi3d55jIdo7.zfmZ8SLtOYrAJgAO6hC98.AO2otBRRC', 'hasan', '');

SET FOREIGN_KEY_CHECKS = 1;
