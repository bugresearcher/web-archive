<?php
include('header.php');
$site_hal = site_hal;
if (isset($_GET['s'])) {
    $noS = $_GET['s'];
}
else
    $noS = 1;
$offset = ($noS - 1) * $site_hal;
?>
<br><br>


						
<div class="container">

<ul class="breadcrumb">
	<li>
		<i class="icon-home"></i>
		<a>Home</a> 
		<i class="icon-angle-right"></i>
	</li>
	<li><a href="/ranked/1"><i class="icon-user"></i> Activist</a></li>
</ul>

        <div class="row">
            <div class="col-lg-12">								
                <div class="panel panel-default" id="tables">
                    <div class="panel-heading"><i class="icon-user"></i> Activists or Groups
                    </div>
					<div class="panel-body">
						<table class="table table-hover">
							<thead>
								  <tr>
								  	  <th style="width:5%;">#No</th>
									  <th style="width:5%;">Country</th>
									  <th style="width:24%;">Attacker</th>
									  <th style="width:10%;">Status</th>
									  <th style="width:25%;">Total</th>
									  <th style="width:5%;">Preview</th>

                                        
								  </tr>
							  </thead>   
							  <?php
                $db->go("SELECT * FROM hacker ORDER BY deface DESC LIMIT $offset, $site_hal");
                $no = 1;
                while ($data = $db->fetchArray()) {
                    ?>
							  <tbody>
							  
							  
								<tr>
									<td><?php echo $no; ?></td>								
									<td class="center" style="text-align: center"><img src="https://mirror-h.org/templates/dark/flags/TR.png" style="height:25px;"></td>
									<td><a href="<?php echo url_site; ?>search.php?search=<?php echo $data['hacker']; ?>"><?php echo htmlspecialchars($data['hacker']); ?></a></td>
									<td class="center">Standard</td>
									<td class="center"><?php echo $data['deface']; ?></td>
									<td class="center"><a href="<?php echo url_site; ?>search.php?search=<?php echo $data['hacker']; ?>"><i class="icon-search"></i></a></td>
                                      
								</tr>
	
							</tbody>
							 <?php 
    $no++;
    } ?>
						</table>
</div>
</div>
    <div class="row">
        <div class="col-sm-12">
            <div class="pull-right">
                <div class="dataTables_paginate paging_bootstrap">
                    <ul class="pagination pagination-sm">
                        <?php
                        $db->go("SELECT COUNT(*) AS jumData FROM hacker ORDER BY deface");
                        $data = $db->fetchArray();
                        $jumData = $data['jumData'];
                        $jumPage = ceil($jumData / $site_hal);
                        // menampilkan link previous
                        if ($noS > 1)
                            echo "<li class='prev'><a href='".site_url."ranked/" . ($noS - 1) . "'> Prev</a></li>";

                        for ($page = 1; $page <= $jumPage; $page++) {
                            if ((($page >= $noS - 3) && ($page <= $noS + 3)) || ($page == 1) || ($page == $jumPage)) {
                                if (($showPage == 1) && ($page != 2))
                                    echo "...";
                                if (($showPage != ($jumPage - 1)) && ($page == $jumPage))
                                    echo "...";
                                if ($page == $noPage)
                                    echo " <li><a>" . $page . "</a></li> ";
                                else
                                    echo " <li><a href='".site_url."ranked/" . $page . "'>" . $page . "</a></li> ";
                                $showPage = $page;
                            }
                        }

                        // menampilkan link next

                        if ($noS < $jumPage)
                            echo "<li class='next'><a href='".site_url."ranked/" . ($noS + 1) . "'>Next</a></li>";
                        ?>
                    </ul>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php include('footer.php'); ?>