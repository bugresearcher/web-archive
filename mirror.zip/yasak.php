<?php 

function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
    $support    = array("country", "countrycode", "state", "region", "city", "location", "address");
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city"           => @$ipdat->geoplugin_city,
                        "state"          => @$ipdat->geoplugin_regionName,
                        "country"        => @$ipdat->geoplugin_countryName,
                        "country_code"   => @$ipdat->geoplugin_countryCode,
                        "continent"      => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array($ipdat->geoplugin_countryName);
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
}


function isletimsistemi() {
$tespit=$_SERVER['HTTP_USER_AGENT'];
if(stristr($tespit,"Windows 95")) { $os="Windows 95"; }
elseif(stristr($tespit,"Windows 98")) { $os="Windows 98"; }
elseif(stristr($tespit,"Windows NT 5.0")) { $os="Windows 2000"; }
elseif(stristr($tespit,"Windows NT 5.1")) { $os="Windows XP"; }
elseif(stristr($tespit,"Windows NT 6.0")) { $os="Windows Vista"; }
elseif(stristr($tespit,"Windows NT 6.1")) { $os="Windows 7"; }
elseif(stristr($tespit,"Windows NT 6.2")) { $os="Windows 8"; }
elseif(stristr($tespit,"Mac")) { $os="Mac"; }
elseif(stristr($tespit,"Linux")) { $os="Linux"; }
else {$os="Bilinmiyor ?";}
return $os;
}
 
function tarayici() {
$tespit2=$_SERVER['HTTP_USER_AGENT'];
if(stristr($tespit2,"MSIE")) { $tarayici="Internet Explorer"; }
elseif(stristr($tespit2,"Firefox")) { $tarayici="Mozilla Firefox"; }
elseif(stristr($tespit2,"YaBrowser")) { $tarayici="Yandex Browser"; }
elseif(stristr($tespit2,"Chrome")) { $tarayici="Google Chrome"; }
elseif(stristr($tespit2,"Safari")) { $tarayici="Safari"; }
elseif(stristr($tespit2,"Opera")) { $tarayici="Opera"; }
else {$tarayici="Bilinmiyor ?";}
return $tarayici;
}

?>
<?php

$bolge = ip_info("Visitor", "City");
?>

<?php

if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}

?>
<body bgcolor="black">
<title> kekir denetimi</title>
<iframe src="essek.mp3" width="0" height="0"> </iframe>
<div align="center">
<p align="center">
<img border="0" src="http://c12.incisozluk.com.tr/res/incisozluk//11504/8/2347478_o8868.jpg" width="280" height="240"><br>
<br>
<font face="Courier New" color="white" size="5"><font color="#8b0000">403</font>
<br>
<br>
<font face="Courier New" color="#8b0000" size="4"><b> Anti Bebe</b><br><b></b>
<br>
Pişşttt Yavrum Napıyorsun Burda :)

<br> İP Adresin: <?php echo $ip; ?>
<br>Konumun: <?php

echo $bolge = ip_info("Visitor", "City");
?>  
<br> İşletim Sisteminiz: <?php echo isletimsistemi(); ?>
<br> Tarayiciniz: <?php echo tarayici(); ?>
<br>İP ADRESİNİZ LOGLANMİSTİR.
<br>Bu Site Diyanet İşleri Başkanlığı <br>Tarafından Korunmaktadir Saygilarimizla. <br> Diyanet: +90(312) 295 70 00 <br> <a href="https://www.diyanet.gov.tr/tr-TR">https://www.diyanet.gov.tr/tr-TR</a></font></font></b><br>
<br>
   




</div>

</body></html>